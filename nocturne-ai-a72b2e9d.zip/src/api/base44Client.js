import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68568fda1c44cf4aa72b2e9d", 
  requiresAuth: true // Ensure authentication is required for all operations
});
